import { useEffect, useState } from 'react';
import axios from '../api/axios';

interface UserInfo {
  namaToko: string;
  email: string;
}

export default function About() {
  const [info, setInfo] = useState<UserInfo | null>(null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const token = localStorage.getItem('token'); // Pastikan token disimpan saat login
        const res = await axios.get('/auth/user', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setInfo(res.data);
      } catch (err) {
        console.error('Gagal mengambil data user', err);
      }
    };

    fetchUserInfo();
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Tentang Toko</h1>
      {info ? (
        <div>
          <p><strong>Nama Toko:</strong> {info.namaToko}</p>
          <p><strong>Email:</strong> {info.email}</p>
        </div>
      ) : (
        <p>Aplikasi ini dirancang unutuk pemilik toko juga para pedagang kecil sampai kelas 
        menengah. Terkadang pemilik toko kesusahan untuk mencatat keuangannya baik dari segi 
        pemasukan, pengeluaran, gaji karyawan bahkan Ketika dia memiliki keuntungan dia tidak tau 
        jumlahnya berapa. Bukan hanya keuangan, jumlah barang juga harus di hitung dan dipastikan sesuai 
        dengan kebutuhan baik dari segi modal dan perencanaan kedepannya akan bagaimana. 
        Pemilik toko juga diharapkan harus mampu melihat data-data yang ada seperti,
        barang seperti apa yang disukai  dan digemari para pembeli, mana yang harus dikurangi 
        dan mana yang harus diperbanyak agar 
        sesuai dengan target pasar yang ada sampai saat ini.
        TokoKu bertujuan untuk menjadi platform e-commerce terpercaya dan populer di Indonesia, yang memudahkan pengguna untuk berbelanja dan berjualan online.
          Manfaat:
1. Kemudahan Berbelanja: TokoKu memungkinkan pengguna untuk berbelanja online dengan mudah dan nyaman.
2. Akses ke Berbagai Produk: Pengguna dapat menemukan berbagai produk dari berbagai penjual.
3. Kesempatan Berjualan: TokoKu memberikan kesempatan kepada pengguna untuk menjual produk mereka secara online.
</p>
      
      )}
    </div>
  );
}
