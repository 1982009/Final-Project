import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import axios from '../api/axios';

type RegisterForm = {
  namaToko: string;
  email: string;
  password: string;
};

export default function Register() {
  const navigate = useNavigate();
  const { register, handleSubmit } = useForm<RegisterForm>();

  const onSubmit = async (data: RegisterForm) => {
    await axios.post('/auth/register', data);
    alert('Register berhasil');
    navigate('/login');
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-4 border rounded shadow">
      <h1 className="text-xl font-bold mb-4">Register</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <input {...register('namaToko')} className="w-full p-2 border" placeholder="Nama Toko" />
        <input {...register('email')} className="w-full p-2 border" placeholder="Email" />
        <input {...register('password')} type="password" className="w-full p-2 border" placeholder="Password" />
        <button className="w-full bg-green-600 text-white py-2">Register</button>
      </form>
      <p className="mt-4 text-sm text-center">
      Sudah punya akun?{' '}
      <Link to="/login" className="text-blue-600 hover:underline">
        di sini
      </Link>
      </p>
    </div>
  );
}
