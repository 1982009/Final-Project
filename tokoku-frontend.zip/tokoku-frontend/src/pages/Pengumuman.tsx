import { useEffect, useState } from 'react';
import axios from '../api/axios';

interface Pengumuman {
  id: string;
  judul: string;
  isi: string;
}

export default function PengumumanPage() {
  const [data, setData] = useState<Pengumuman[]>([]);
  const [form, setForm] = useState<Omit<Pengumuman, 'id'>>({ judul: '', isi: '' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const loadPengumuman = () => {
    axios.get('/pengumuman').then((res) => setData(res.data));
  };

  useEffect(() => {
    loadPengumuman();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    if (!form.judul || !form.isi) return alert('Judul dan isi wajib diisi');

    try {
      if (editingId) {
        await axios.patch(`/pengumuman/${editingId}`, form);
      } else {
        await axios.post('/pengumuman', form);
      }
      setShowModal(false);
      setForm({ judul: '', isi: '' });
      setEditingId(null);
      loadPengumuman();
    } catch (err) {
      alert('Gagal menyimpan data');
    }
  };

  const handleEdit = (item: Pengumuman) => {
    setForm({ judul: item.judul, isi: item.isi });
    setEditingId(item.id);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Yakin ingin menghapus pengumuman ini?')) {
      await axios.delete(`/pengumuman/${id}`);
      loadPengumuman();
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Pengumuman</h1>

      <button
        onClick={() => {
          setShowModal(true);
          setForm({ judul: '', isi: '' });
          setEditingId(null);
        }}
        className="mb-4 bg-blue-500 text-white px-4 py-2 rounded"
      >
        Tambah Pengumuman
      </button>

      <div className="space-y-4">
        {data.map((item) => (
          <div key={item.id} className="border p-4 rounded shadow">
            <h2 className="font-bold text-lg">{item.judul}</h2>
            <p>{item.isi}</p>
            <div className="mt-2 space-x-2">
              <button onClick={() => handleEdit(item)} className="bg-yellow-500 text-white px-3 py-1 rounded">Edit</button>
              <button onClick={() => handleDelete(item.id)} className="bg-red-600 text-white px-3 py-1 rounded">Hapus</button>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-10">
          <div className="bg-white p-6 rounded shadow w-[90%] max-w-md">
            <h2 className="text-lg font-bold mb-4">{editingId ? 'Edit Pengumuman' : 'Tambah Pengumuman'}</h2>
            <input
              name="judul"
              value={form.judul}
              onChange={handleChange}
              placeholder="Judul"
              className="w-full border p-2 mb-2"
              required
            />
            <textarea
              name="isi"
              value={form.isi}
              onChange={handleChange}
              placeholder="Isi pengumuman"
              className="w-full border p-2 mb-4"
              required
            />
            <div className="flex justify-end space-x-2">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
              <button onClick={handleSubmit} className="px-4 py-2 bg-green-600 text-white rounded">Simpan</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
