import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { Link } from 'react-router-dom';
import axios from '../api/axios';

type LoginForm = {
  email: string;
  password: string;
};

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const { register, handleSubmit } = useForm<LoginForm>();

  const onSubmit = async (data: LoginForm) => {
    const res = await axios.post('/auth/login', data);
    login(res.data.access_token);
    navigate('/');
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-4 border rounded shadow">
      <h1 className="text-xl font-bold mb-4">Login</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <input {...register('email')} className="w-full p-2 border" placeholder="Email" />
        <input {...register('password')} type="password" className="w-full p-2 border" placeholder="Password" />
        <button className="w-full bg-blue-600 text-white py-2">Login</button>
      </form>
      <p className="mt-4 text-sm text-center">
      Belum punya akun?{' '}
      <Link to="/register" className="text-blue-600 hover:underline">
        Daftar di sini
      </Link>
      </p>

    </div>
  );
}
