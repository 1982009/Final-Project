import { useEffect, useState } from 'react';
import axios from '../api/axios';

interface Pengumuman {
  id: string;
  judul: string;
  isi: string;
}

export default function Dashboard() {
  const [data, setData] = useState<Pengumuman[]>([]);

  useEffect(() => {
    axios.get('/pengumuman').then(res => setData(res.data));
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Dashboard - Pengumuman</h1>
      <ul>
        {data.map((item) => (
          <li key={item.id} className="border-b py-2">
            <strong>{item.judul}</strong>
            <p>{item.isi}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
