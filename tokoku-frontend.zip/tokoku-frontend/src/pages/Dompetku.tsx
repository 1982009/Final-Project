import { useEffect, useState } from 'react';
import axios from '../api/axios';

interface Transaksi {
  id: string;
  keterangan: string;
  jumlah: number;
}

interface Barang {
  id: string;
  nama: string;
  harga: number;
}

export default function Dompetku() {
  const [list, setList] = useState<Transaksi[]>([]);
  const [barangList, setBarangList] = useState<Barang[]>([]);
  const [selectedBarang, setSelectedBarang] = useState<string>('');
  const [jumlah, setJumlah] = useState<number>(1);

  const loadTransaksi = () => {
    axios.get('/dompetku').then(res => setList(res.data));
  };

  const loadBarang = () => {
    axios.get('/barang').then(res => setBarangList(res.data));
  };

  useEffect(() => {
    loadTransaksi();
    loadBarang();
  }, []);

  const handlePesan = async () => {
    if (!selectedBarang || jumlah <= 0) {
      alert('Pilih barang dan jumlah valid');
      return;
    }

    const barang = barangList.find(b => b.id === selectedBarang);
    if (!barang) return;

    const totalHarga = barang.harga * jumlah;

    try {
      await axios.post('/dompetku', {
        keterangan: `Pembelian ${barang.nama} x${jumlah}`,
        jumlah: totalHarga,
      });
      setSelectedBarang('');
      setJumlah(1);
      loadTransaksi();
      alert('Transaksi berhasil dibuat');
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Gagal membuat transaksi');
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Dompetku</h1>

      <div className="mb-6 p-4 border rounded">
        <h2 className="text-lg font-semibold mb-2">Pesan Barang</h2>

        <div className="mb-2">
          <select
            className="w-full p-2 border rounded"
            value={selectedBarang}
            onChange={(e) => setSelectedBarang(e.target.value)}
          >
            <option value="">-- Pilih Barang --</option>
            {barangList.map((b) => (
              <option key={b.id} value={b.id}>
                {b.nama} (Rp{b.harga})
              </option>
            ))}
          </select>
        </div>

        <div className="mb-2">
          <input
            type="number"
            className="w-full p-2 border rounded"
            value={jumlah}
            onChange={(e) => setJumlah(Number(e.target.value))}
            min={1}
            placeholder="Jumlah"
          />
        </div>

        <button onClick={handlePesan} className="w-full bg-green-600 text-white py-2 rounded">
          Pesan Sekarang
        </button>
      </div>

      <h2 className="text-lg font-semibold mb-2">Riwayat Transaksi</h2>
      <ul>
        {list.map(item => (
          <li key={item.id} className="border-b py-2">
            <p>{item.keterangan} - <strong>Rp{item.jumlah}</strong></p>
          </li>
        ))}
      </ul>
    </div>
  );
}
