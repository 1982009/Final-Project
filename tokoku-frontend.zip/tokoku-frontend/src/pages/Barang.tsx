import { useEffect, useState } from 'react';
import axios from '../api/axios';

interface Barang {
  id: string;
  nama: string;
  jenis: string;
  harga: number;
}

export default function BarangPage() {
  const [barangList, setBarangList] = useState<Barang[]>([]);
  const [form, setForm] = useState<Omit<Barang, 'id'>>({ nama: '', jenis: '', harga: 0 });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const loadBarang = () => {
    axios.get('/barang')
      .then((res) => setBarangList(res.data))
      .catch((err) => alert(err?.response?.data?.message || 'Gagal load data'));
  };

  useEffect(() => {
    loadBarang();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (name === 'harga') {
      setForm({ ...form, [name]: Number(value) }); // harga harus number
    } else {
      setForm({ ...form, [name]: value });
    }
  };

  const resetForm = () => {
    setForm({ nama: '', jenis: '', harga: 0 });
    setEditingId(null);
    setShowModal(false);
  };

  const handleSubmit = async () => {
    if (!form.nama.trim() || !form.jenis.trim() || form.harga <= 0) {
      alert('Semua field wajib diisi dengan benar');
      return;
    }

    try {
      if (editingId) {
        await axios.patch(`/barang/${editingId}`, form);
      } else {
        await axios.post('/barang', form);
      }
      loadBarang();
      resetForm();
      alert('Data berhasil disimpan');
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Gagal menyimpan data');
    }
  };

  const handleEdit = (barang: Barang) => {
    setForm({ nama: barang.nama, jenis: barang.jenis, harga: barang.harga });
    setEditingId(barang.id);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Yakin ingin menghapus barang ini?')) {
      try {
        await axios.delete(`/barang/${id}`);
        loadBarang();
        alert('Barang berhasil dihapus');
      } catch (err: any) {
        alert(err?.response?.data?.message || 'Gagal menghapus barang');
      }
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Data Barang</h1>

      <button
        onClick={() => {
          setShowModal(true);
          setForm({ nama: '', jenis: '', harga: 0 });
          setEditingId(null);
        }}
        className="mb-4 bg-blue-500 text-white px-4 py-2 rounded"
      >
        Tambah Barang
      </button>

      <table className="w-full border text-left">
        <thead>
          <tr>
            <th className="border p-2">Nama</th>
            <th className="border p-2">Jenis</th>
            <th className="border p-2">Harga</th>
            <th className="border p-2">Aksi</th>
          </tr>
        </thead>
        <tbody>
          {barangList.map((barang) => (
            <tr key={barang.id}>
              <td className="border p-2">{barang.nama}</td>
              <td className="border p-2">{barang.jenis}</td>
              <td className="border p-2">Rp{barang.harga.toLocaleString('id-ID')}</td>
              <td className="border p-2 space-x-2">
                <button
                  onClick={() => handleEdit(barang)}
                  className="bg-yellow-500 text-white px-2 py-1 rounded"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(barang.id)}
                  className="bg-red-500 text-white px-2 py-1 rounded"
                >
                  Hapus
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-10">
          <div className="bg-white p-6 rounded shadow w-[90%] max-w-md">
            <h2 className="text-lg font-bold mb-4">{editingId ? 'Edit Barang' : 'Tambah Barang'}</h2>
            <input
              name="nama"
              value={form.nama}
              onChange={handleChange}
              placeholder="Nama Barang"
              className="w-full border p-2 mb-2"
              required
            />
            <input
              name="jenis"
              value={form.jenis}
              onChange={handleChange}
              placeholder="Jenis Barang"
              className="w-full border p-2 mb-2"
              required
            />
            <input
              name="harga"
              type="number"
              value={form.harga}
              onChange={handleChange}
              placeholder="Harga"
              className="w-full border p-2 mb-4"
              min="0"
              required
            />
            <div className="flex justify-end space-x-2">
              <button onClick={resetForm} className="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
              <button onClick={handleSubmit} className="px-4 py-2 bg-green-600 text-white rounded">Simpan</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
