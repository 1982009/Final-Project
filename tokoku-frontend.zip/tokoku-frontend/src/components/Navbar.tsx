import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

const Navbar = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  return (
    <nav className="bg-gray-800 p-4 text-white flex justify-between">
      <div className="space-x-4">
        <Link to="/">Dashboard</Link>
        <Link to="/about">About</Link>
        <Link to="/dompetku">Dompetku</Link>
        <Link to="/barang">Barang</Link>
        <Link to="/pengumuman">Pengumuman</Link>
      </div>
      <button onClick={() => { logout(); navigate('/login'); }} className="text-red-300 hover:underline">
        Logout
      </button>
    </nav>
  );
};

export default Navbar;
